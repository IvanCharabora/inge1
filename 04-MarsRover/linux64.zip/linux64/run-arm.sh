#!/bin/bash
vmLiveTyping-ARM/squeak CuisUniversity-5799.image