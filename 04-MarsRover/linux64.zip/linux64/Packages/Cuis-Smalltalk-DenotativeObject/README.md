# Cuis-Smalltalk-DenotativeObject
A tool that allows to work with objects whitout classes.
The solution is simple, it uses the class side of classes and shows that as objects in specialized tools like a browser, inspector, debugger, etc.

It has support for testing also.
To use it, select the option "Open DenotativeBrowser" from the World Menu.

# Dependencies
The refactoring package must be install because the denotative browser allows refactorings to be executed. You can download the refactoring package from https://github.com/hernanwilkinson/Cuis-Smalltalk-Refactoring
