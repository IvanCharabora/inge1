# SystemCategoryAutoSaving
Provisto por Ariel Camblor para grabar una categoría de clases cada cierto tiempo.
Muchas gracias Ari!
