#!/bin/bash
vmLiveTyping-Stack/squeak CuisUniversity-5799.image