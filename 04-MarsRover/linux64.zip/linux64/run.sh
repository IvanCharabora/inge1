#!/bin/bash
vmLiveTyping/squeak CuisUniversity-5799.image