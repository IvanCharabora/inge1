#!/bin/bash
vm-jit/squeak CuisUniversity-5799.image